import { useEffect, useState, type CSSProperties } from 'react';
import { API_BASE_URL } from '../config';

type FeedbackProps = {
  ticketId: string;
  responseId: string,
  applicationName: string,
  userId: string
};      

const LOW_RATING_THRESHOLD = 3;
const MAX_COMMENT_LENGTH = 150;

export default function FeedbackSection({ ticketId, responseId, applicationName, userId}: FeedbackProps) {
  // userId is provided by the parent via SSO/cookie-based auth, no manual email entry needed.
  const [email] = useState<string>(userId);
  const [rating, setRating] = useState<number>(0);
  const [comment, setComment] = useState<string>('');

  const [loading, setLoading] = useState<boolean>(true);
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [submitted, setSubmitted] = useState<boolean>(false);

  const [error, setError] = useState<string>('');
  const [success, setSuccess] = useState<string>('');

  const [accuracyScore, setAccuracyScore] = useState<number | null>(null);
  const [accuracyLoading, setAccuracyLoading] = useState<boolean>(false);

  const fetchAccuracyScore = async () => {
  try {
    setAccuracyLoading(true);

    const response = await fetch(
      `${API_BASE_URL}/api/accuracy-score/${encodeURIComponent(applicationName)}`
    );

    if (!response.ok) {
      throw new Error('Failed to load accuracy score');
    }

    const data = await response.json();

    setAccuracyScore(data.accuracyScore);
  } catch (error) {
    console.error('Error loading accuracy score:', error);
  } finally {
    setAccuracyLoading(false);
  }
};

  useEffect(() => {
    const fetchFeedback = async () => {
      try {
        const response = await fetch(
          `${API_BASE_URL}/api/feedback/${ticketId}`
        );

        if (!response.ok) {
          throw new Error('Failed to load feedback');
        }

        const data = await response.json();

        if (data) {
          setRating(data.star_rating);
          setComment(data.comment);
          setSubmitted(true);
        }
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchFeedback();
  }, [ticketId]);

  const submitFeedback = async () => {
    setError('');
    setSuccess('');

    if (rating === 0) {
      setError('Please select a star rating.');
      return;
    }

    if (rating <= LOW_RATING_THRESHOLD && !comment.trim()) {
      setError('Comment is mandatory for ratings of 3 stars or below.');
      return;
    }

    if (comment.length > MAX_COMMENT_LENGTH) {
      setError(`Comment cannot exceed ${MAX_COMMENT_LENGTH} characters.`);
      return;
    }

    try {
      setSubmitting(true);

      const response = await fetch(
        `${API_BASE_URL}/api/feedback`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            incidentId: ticketId,
            responseId: responseId,
            applicationName: applicationName,
            userId: email,
            accuracyRating: rating,
            comments: comment,
            createdBy: email
          }),
        }
      );

      const result = await response.json();

      if (!response.ok) {
        throw new Error(
          result.detail || 'Failed to submit feedback'
        );
      }

      setSuccess('Feedback submitted successfully.');
      await fetchAccuracyScore();
      setSubmitted(true);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div style={{ marginTop: '20px' }}>
        Loading Feedback...
      </div>
    );
  }

  const isLowRating = rating > 0 && rating <= LOW_RATING_THRESHOLD;

  const segmentStyle: CSSProperties = {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    padding: '0 16px',
    borderRight: '1px dashed #d1d5db',
    whiteSpace: 'nowrap',
  };

  return (
    <div
      style={{
        marginTop: '20px',
        border: '1px solid #dcdcdc',
        borderRadius: '8px',
        padding: '16px',
      }}
    >
      <h3 style={{ marginTop: 0, marginBottom: '12px' }}>Feedback</h3>

      <div
        style={{
          display: 'flex',
          alignItems: 'stretch',
          overflowX: 'auto',
          backgroundColor: '#f9fafb',
          border: '1px solid #e5e7eb',
          borderRadius: '999px',
          padding: '10px 0',
        }}
      >
        <div style={segmentStyle}>
          {[1, 2, 3, 4, 5].map((star) => (
            <span
              key={star}
              onClick={() => {
                if (!submitted) {
                  setRating(star);
                }
              }}
              style={{
                fontSize: '22px',
                lineHeight: 1,
                cursor: submitted ? 'default' : 'pointer',
                color: star <= rating ? '#facc15' : '#d1d5db',
              }}
            >
              ★
            </span>
          ))}
        </div>

        <div style={{ ...segmentStyle, flex: 1, minWidth: '220px' }}>
          <input
            type="text"
            value={comment}
            disabled={submitted || !email}
            maxLength={MAX_COMMENT_LENGTH}
            placeholder={
              isLowRating
                ? 'Please tell us what went wrong (required)'
                : 'Enter your feedback'
            }
            onChange={(e) =>
              setComment(e.target.value.slice(0, MAX_COMMENT_LENGTH))
            }
            style={{
              width: '100%',
              border: 'none',
              outline: 'none',
              background: 'transparent',
              fontSize: '14px',
              color: '#111827',
            }}
          />
          {!submitted && (
            <span
              style={{
                fontSize: '11px',
                color: comment.length >= MAX_COMMENT_LENGTH ? '#b91c1c' : '#9ca3af',
              }}
            >
              {comment.length}/{MAX_COMMENT_LENGTH}
            </span>
          )}
        </div>

        <div style={{ display: 'flex', alignItems: 'center', padding: '0 16px', whiteSpace: 'nowrap' }}>
          {!submitted ? (
            <button
              onClick={submitFeedback}
              disabled={submitting || !email}
              style={{
                backgroundColor: '#2563eb',
                color: 'white',
                padding: '8px 16px',
                border: 'none',
                borderRadius: '999px',
                cursor: 'pointer',
                fontSize: '13px',
                fontWeight: 600,
              }}
            >
              {submitting ? 'Submitting...' : 'Submit'}
            </button>
          ) : (
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              <span style={{ color: '#15803d', fontWeight: 600, fontSize: '13px' }}>
                ✓ Submitted
              </span>
              {accuracyLoading ? (
                <span style={{ fontSize: '12px', color: '#6b7280' }}>Loading score...</span>
              ) : accuracyScore !== null ? (
                <span style={{ fontSize: '12px', color: '#111827' }}>
                  Accuracy: <strong>{accuracyScore}%</strong>
                </span>
              ) : (
                <span style={{ fontSize: '12px', color: '#6b7280' }}>Score unavailable</span>
              )}
            </div>
          )}
        </div>
      </div>

      {error && (
        <div
          style={{
            color: '#b91c1c',
            marginTop: '10px',
            fontSize: '13px',
          }}
        >
          {error}
        </div>
      )}

      {success && (
        <div
          style={{
            color: '#15803d',
            marginTop: '10px',
            fontSize: '13px',
          }}
        >
          {success}
        </div>
      )}
    </div>
  );
}
