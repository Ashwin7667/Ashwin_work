// Centralized runtime configuration sourced from environment variables (see .env / .env.example).
export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://127.0.0.1:8000';

// Demo/sample context used until real ticket routing and SSO identity wiring are in place.
export const DEMO_CONTEXT = {
  ticketId: import.meta.env.VITE_DEMO_TICKET_ID || 'INC10001',
  responseId: import.meta.env.VITE_DEMO_RESPONSE_ID || 'RESP10001',
  applicationName: import.meta.env.VITE_DEMO_APPLICATION_NAME || 'Service Assist',
  userId: import.meta.env.VITE_DEMO_USER_ID || 'abc@gmail.com',
};
