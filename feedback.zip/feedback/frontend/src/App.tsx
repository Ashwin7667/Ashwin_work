import FeedbackSection from "./components/FeedbackSection";
import { DEMO_CONTEXT } from "./config";

export default function App() {
  return (
    <div
      style={{
        maxWidth: "800px",
        margin: "40px auto",
        padding: "20px",
      }}
    >
      <FeedbackSection
        ticketId={DEMO_CONTEXT.ticketId}
        responseId={DEMO_CONTEXT.responseId}
        applicationName={DEMO_CONTEXT.applicationName}
        userId={DEMO_CONTEXT.userId}
      />
    </div>
  );
}
