from database import get_db_connection

connection = None
cursor = None

try:
    connection = get_db_connection()

    cursor = connection.cursor()

    cursor.execute("""
        SELECT current_database(), current_user
    """)

    result = cursor.fetchone()

    print("Connected successfully")
    print("Database:", result[0])
    print("User:", result[1])

except Exception as error:
    print("Database connection failed:")
    print(error)
finally:
    if cursor is not None:
        cursor.close()
    if connection is not None:
        connection.close()

finally:
    if cursor is not None:
        cursor.close()

    if connection is not None:
        connection.close()