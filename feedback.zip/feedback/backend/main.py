import os
from typing import Optional
from decimal import Decimal

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field, model_validator

from database import get_db_connection, load_env_file

load_env_file()

LOW_RATING_THRESHOLD = 3
MAX_COMMENT_LENGTH = 150

APP_TITLE = os.getenv("APP_TITLE", "Service Assist Feedback API")
APP_VERSION = os.getenv("APP_VERSION", "1.0.0")
APP_DESCRIPTION = os.getenv(
    "APP_DESCRIPTION",
    "Stores feedback and calculates application-level accuracy from PostgreSQL.",
)
CORS_ORIGINS = [
    origin.strip()
    for origin in os.getenv(
        "CORS_ORIGINS",
        "http://localhost:5173,http://127.0.0.1:5173,http://localhost:3000,http://127.0.0.1:3000",
    ).split(",")
    if origin.strip()
]

app = FastAPI(
    title=APP_TITLE,
    version=APP_VERSION,
    description=APP_DESCRIPTION,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class FeedbackRequest(BaseModel):
    incidentId: str = Field(min_length=1, max_length=50)
    responseId: Optional[str] = Field(default=None, max_length=100)
    applicationName: str = Field(min_length=1, max_length=100)
    userId: Optional[str] = Field(default=None, max_length=100)
    accuracyRating: int = Field(ge=1, le=5)
    comments: Optional[str] = Field(default=None, max_length=MAX_COMMENT_LENGTH)
    createdBy: Optional[str] = Field(default=None, max_length=100)

    @model_validator(mode="after")
    def validate_comment(self):
        comment = (self.comments or "").strip()
        if self.accuracyRating <= LOW_RATING_THRESHOLD and not comment:
            raise ValueError(
                f"Comment is mandatory for ratings of {LOW_RATING_THRESHOLD} stars or below."
            )
        return self


@app.get("/")
def home():
    return {"message": f"{APP_TITLE} is running"}


@app.get("/api/health/database")
def check_database_connection():
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        cursor = connection.cursor()
        cursor.execute("SELECT current_database(), current_user")
        result = cursor.fetchone()
        return {"status": "connected", "database": result[0], "user": result[1]}
    except Exception as error:
        raise HTTPException(status_code=500, detail=f"Database connection failed: {error}")
    finally:
        if cursor is not None:
            cursor.close()
        if connection is not None:
            connection.close()


@app.post("/api/feedback", status_code=201)
def create_feedback(feedback: FeedbackRequest):
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        cursor = connection.cursor()
        cursor.execute(
            """
            INSERT INTO feedback_table (
                incident_id,
                response_id,
                application_name,
                user_id,
                accuracy_rating,
                comments,
                created_by
            )
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            RETURNING feedback_id, created_date
            """,
            (
                feedback.incidentId,
                feedback.responseId,
                feedback.applicationName,
                feedback.userId,
                feedback.accuracyRating,
                feedback.comments,
                feedback.createdBy or feedback.userId,
            ),
        )
        record = cursor.fetchone()
        connection.commit()
        return {
            "message": "Feedback submitted successfully",
            "feedbackId": record[0],
            "createdDate": record[1],
        }
    except Exception as error:
        if connection is not None:
            connection.rollback()
        raise HTTPException(status_code=500, detail=f"Could not save feedback: {error}")
    finally:
        if cursor is not None:
            cursor.close()
        if connection is not None:
            connection.close()


@app.get("/api/accuracy-score/{application_name}")
def get_accuracy_score(application_name: str):
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        cursor = connection.cursor()
        cursor.execute(
            """
            SELECT
                COUNT(*) AS total_ticket_count,
                COALESCE(
                    ROUND(
                        AVG(
                            CASE accuracy_rating
                                WHEN 5 THEN 100.0
                                WHEN 4 THEN 85.0
                                WHEN 3 THEN 70.0
                                WHEN 2 THEN 50.0
                                WHEN 1 THEN 0.0
                            END
                        ),
                        2
                    ),
                    0
                ) AS accuracy_score
            FROM feedback_table
            WHERE application_name = %s
            """,
            (application_name,),
        )
        result = cursor.fetchone()
        score = float(result[1]) if isinstance(result[1], Decimal) else result[1]
        return {
            "applicationName": application_name,
            "totalTicketCount": result[0],
            "accuracyScore": score,
            "thresholdStatus": "Meeting Target" if score >= 85 else "Review Required",
        }
    except Exception as error:
        raise HTTPException(status_code=500, detail=f"Could not calculate accuracy: {error}")
    finally:
        if cursor is not None:
            cursor.close()
        if connection is not None:
            connection.close()
