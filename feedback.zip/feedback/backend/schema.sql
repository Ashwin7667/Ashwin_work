CREATE TABLE IF NOT EXISTS feedback_table (
    feedback_id BIGSERIAL PRIMARY KEY,
    incident_id VARCHAR(50) NOT NULL,
    response_id VARCHAR(100),
    application_name VARCHAR(100) NOT NULL,
    user_id VARCHAR(100),
    accuracy_rating INT NOT NULL CHECK (accuracy_rating BETWEEN 1 AND 5),
    comments TEXT,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(100)
);

CREATE TABLE IF NOT EXISTS accuracy_metrics_table_updated (
    metric_id BIGSERIAL PRIMARY KEY,
    application_name VARCHAR(100) NOT NULL,
    total_ticket_count INT DEFAULT 0,
    accuracy_score NUMERIC(5,2),
    threshold_status VARCHAR(50),
    calculation_date DATE,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
