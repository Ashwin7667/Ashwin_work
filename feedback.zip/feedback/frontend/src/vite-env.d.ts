/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_API_BASE_URL: string;
  readonly VITE_DEMO_TICKET_ID: string;
  readonly VITE_DEMO_RESPONSE_ID: string;
  readonly VITE_DEMO_APPLICATION_NAME: string;
  readonly VITE_DEMO_USER_ID: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
