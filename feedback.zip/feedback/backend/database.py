import os
from pathlib import Path

import pg8000


def load_env_file():
    """Small .env reader so python-dotenv is not required."""
    env_path = Path(__file__).with_name(".env")
    if not env_path.exists():
        return

    for raw_line in env_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        os.environ.setdefault(key, value)


load_env_file()


def get_db_connection():
    password = os.getenv("DB_PASSWORD")
    if not password or password == "REPLACE_WITH_YOUR_POSTGRES_PASSWORD":
        raise RuntimeError("Set DB_PASSWORD in the .env file before starting the backend.")

    return pg8000.connect(
        host=os.getenv("DB_HOST", "localhost"),
        port=int(os.getenv("DB_PORT", "5432")),
        user=os.getenv("DB_USER", "postgres"),
        password=password,
        database=os.getenv("DB_NAME", "feedback_db"),
        timeout=int(os.getenv("DB_TIMEOUT", "10")),
    )
