@echo off
cd /d "%~dp0"
py -m uvicorn main:app --reload
pause
